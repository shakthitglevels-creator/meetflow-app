import { Router } from "express";

import { authMiddleware } from "../../auth/middlewares/auth.middleware";
import { validate } from "../../../middleware/validate.middleware";

import {
  createMeetingController,
  endMeetingController,
  getMeetingDetailsController,
  getMeetingParticipantsController,
  joinMeetingController,
  leaveMeetingController,
} from "../controllers/meeting.controller";

import { validateParams } from "../middleware/validate-params.middleware";

import { createMeetingSchema } from "../validators/create-meeting.validator";
import { joinMeetingParamsSchema } from "../validators/join-meeting.validator";

const meetingRouter = Router();

/*
 * All meeting routes are protected.
 *
 * The auth middleware verifies:
 * 1. Authorization header exists.
 * 2. Access token is valid.
 * 3. User exists in MongoDB.
 * 4. Email is verified.
 * 5. Account status is active.
 *
 * Because this middleware is added here, we do not
 * need to repeat authMiddleware on every route.
 */
meetingRouter.use(authMiddleware);

/**
 * @openapi
 * /api/meetings:
 *   post:
 *     tags:
 *       - Meetings
 *     summary: Create an instant meeting
 *     description: Creates a new instant meeting for the authenticated and active user.
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: false
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               title:
 *                 type: string
 *                 example: Backend Team Discussion
 *                 description: Optional meeting title. Defaults to Untitled Meeting.
 *     responses:
 *       201:
 *         description: Meeting created successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Meeting created successfully
 *                 data:
 *                   type: object
 *                   properties:
 *                     id:
 *                       type: string
 *                     title:
 *                       type: string
 *                       example: Untitled Meeting
 *                     meetingCode:
 *                       type: string
 *                       example: 8XK29Q
 *                     hostId:
 *                       type: string
 *                     status:
 *                       type: string
 *                       example: open
 *                     startedAt:
 *                       type: string
 *                       format: date-time
 *                     createdAt:
 *                       type: string
 *                       format: date-time
 *       400:
 *         description: Request validation failed
 *       401:
 *         description: Missing, invalid, or expired access token
 *       403:
 *         description: Email is not verified or account is not active
 */
meetingRouter.post(
  "/",
  validate(createMeetingSchema),
  createMeetingController,
);

/**
 * @openapi
 * /api/meetings/{meetingCode}:
 *   get:
 *     tags:
 *       - Meetings
 *     summary: Get meeting details
 *     description: Returns meeting preview information, host details, and the number of currently joined participants.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: meetingCode
 *         required: true
 *         description: Six-character public meeting code
 *         schema:
 *           type: string
 *           minLength: 6
 *           maxLength: 6
 *         example: 8XK29Q
 *     responses:
 *       200:
 *         description: Meeting details fetched successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Meeting details fetched successfully
 *                 data:
 *                   type: object
 *                   properties:
 *                     id:
 *                       type: string
 *                       example: 66a4cdd90ea8fe6863b98c243
 *                     title:
 *                       type: string
 *                       example: Backend Team Discussion
 *                     meetingCode:
 *                       type: string
 *                       example: 8XK29Q
 *                     status:
 *                       type: string
 *                       enum:
 *                         - scheduled
 *                         - open
 *                         - ended
 *                         - cancelled
 *                       example: open
 *                     host:
 *                       type: object
 *                       properties:
 *                         id:
 *                           type: string
 *                         name:
 *                           type: string
 *                           example: Shakthivel
 *                         email:
 *                           type: string
 *                           format: email
 *                           example: shakthi@example.com
 *                         avatar:
 *                           type: string
 *                           nullable: true
 *                     participantCount:
 *                       type: integer
 *                       example: 2
 *                     scheduledAt:
 *                       type: string
 *                       format: date-time
 *                       nullable: true
 *                     startedAt:
 *                       type: string
 *                       format: date-time
 *                       nullable: true
 *                     endedAt:
 *                       type: string
 *                       format: date-time
 *                       nullable: true
 *                     createdAt:
 *                       type: string
 *                       format: date-time
 *       400:
 *         description: Invalid meeting-code format
 *       401:
 *         description: Missing, invalid, or expired access token
 *       403:
 *         description: Email is not verified or account is not active
 *       404:
 *         description: Meeting not found
 */
meetingRouter.get(
  "/:meetingCode",
  validateParams(joinMeetingParamsSchema),
  getMeetingDetailsController,
);

/**
 * @openapi
 * /api/meetings/{meetingCode}/participants:
 *   get:
 *     tags:
 *       - Meetings
 *     summary: Get currently joined meeting participants
 *     description: Returns all participants currently marked as joined, including their basic user details.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: meetingCode
 *         required: true
 *         description: Six-character public meeting code
 *         schema:
 *           type: string
 *           minLength: 6
 *           maxLength: 6
 *         example: 8XK29Q
 *     responses:
 *       200:
 *         description: Meeting participants fetched successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Meeting participants fetched successfully
 *                 data:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       id:
 *                         type: string
 *                       role:
 *                         type: string
 *                         enum:
 *                           - host
 *                           - participant
 *                       status:
 *                         type: string
 *                         enum:
 *                           - joined
 *                           - left
 *                         example: joined
 *                       joinedAt:
 *                         type: string
 *                         format: date-time
 *                       user:
 *                         type: object
 *                         properties:
 *                           id:
 *                             type: string
 *                           name:
 *                             type: string
 *                             example: Shakthivel
 *                           email:
 *                             type: string
 *                             format: email
 *                             example: shakthi@example.com
 *                           avatar:
 *                             type: string
 *                             nullable: true
 *       400:
 *         description: Invalid meeting-code format
 *       401:
 *         description: Missing, invalid, or expired access token
 *       403:
 *         description: Email is not verified or account is not active
 *       404:
 *         description: Meeting not found
 */
meetingRouter.get(
  "/:meetingCode/participants",
  validateParams(joinMeetingParamsSchema),
  getMeetingParticipantsController,
);

/**
 * @openapi
 * /api/meetings/{meetingCode}/join:
 *   post:
 *     tags:
 *       - Meetings
 *     summary: Join an existing meeting
 *     description: Allows an authenticated and active user to join an open meeting using its meeting code.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: meetingCode
 *         required: true
 *         schema:
 *           type: string
 *           minLength: 6
 *           maxLength: 6
 *         example: 8XK29Q
 *     responses:
 *       200:
 *         description: Meeting joined successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Meeting joined successfully
 *                 data:
 *                   type: object
 *                   properties:
 *                     meeting:
 *                       type: object
 *                       properties:
 *                         id:
 *                           type: string
 *                         title:
 *                           type: string
 *                         meetingCode:
 *                           type: string
 *                         hostId:
 *                           type: string
 *                         status:
 *                           type: string
 *                           example: open
 *                         startedAt:
 *                           type: string
 *                           format: date-time
 *                     participant:
 *                       type: object
 *                       properties:
 *                         id:
 *                           type: string
 *                         role:
 *                           type: string
 *                           enum:
 *                             - host
 *                             - participant
 *                         status:
 *                           type: string
 *                           enum:
 *                             - joined
 *                             - left
 *                         joinedAt:
 *                           type: string
 *                           format: date-time
 *       400:
 *         description: Invalid meeting-code format
 *       401:
 *         description: Missing, invalid, or expired access token
 *       403:
 *         description: Account is inactive, email is unverified, or meeting is unavailable
 *       404:
 *         description: Meeting not found
 */
meetingRouter.post(
  "/:meetingCode/join",
  validateParams(joinMeetingParamsSchema),
  joinMeetingController,
);

/**
 * @openapi
 * /api/meetings/{meetingCode}/leave:
 *   post:
 *     tags:
 *       - Meetings
 *     summary: Leave a meeting
 *     description: Marks the authenticated participant as left without deleting their participation record.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: meetingCode
 *         required: true
 *         schema:
 *           type: string
 *           minLength: 6
 *           maxLength: 6
 *         example: 8XK29Q
 *     responses:
 *       200:
 *         description: Meeting left successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Meeting left successfully
 *                 data:
 *                   type: object
 *                   properties:
 *                     meetingCode:
 *                       type: string
 *                       example: 8XK29Q
 *                     participantId:
 *                       type: string
 *                     status:
 *                       type: string
 *                       enum:
 *                         - joined
 *                         - left
 *                       example: left
 *                     leftAt:
 *                       type: string
 *                       format: date-time
 *       400:
 *         description: Invalid meeting-code format
 *       401:
 *         description: Missing, invalid, or expired access token
 *       403:
 *         description: Email is not verified or account is not active
 *       404:
 *         description: Meeting or participant record not found
 *       500:
 *         description: Unable to update participant state
 */
meetingRouter.post(
  "/:meetingCode/leave",
  validateParams(joinMeetingParamsSchema),
  leaveMeetingController,
);

/**
 * @openapi
 * /api/meetings/{meetingCode}/end:
 *   post:
 *     tags:
 *       - Meetings
 *     summary: End a meeting for everyone
 *     description: Allows only the meeting host to end an open meeting. The meeting is marked as ended and all currently joined participants are marked as left.
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: meetingCode
 *         required: true
 *         description: Six-character public meeting code
 *         schema:
 *           type: string
 *           minLength: 6
 *           maxLength: 6
 *         example: 8XK29Q
 *     responses:
 *       200:
 *         description: Meeting ended successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 success:
 *                   type: boolean
 *                   example: true
 *                 message:
 *                   type: string
 *                   example: Meeting ended successfully
 *                 data:
 *                   type: object
 *                   properties:
 *                     meetingCode:
 *                       type: string
 *                       example: 8XK29Q
 *                     status:
 *                       type: string
 *                       enum:
 *                         - ended
 *                       example: ended
 *                     endedAt:
 *                       type: string
 *                       format: date-time
 *                     participantsMarkedLeft:
 *                       type: integer
 *                       example: 3
 *       400:
 *         description: Invalid meeting-code format
 *       401:
 *         description: Missing, invalid, or expired access token
 *       403:
 *         description: Account is inactive, email is unverified, or user is not the meeting host
 *       404:
 *         description: Meeting not found
 *       409:
 *         description: The meeting's current status does not allow it to be ended
 *       500:
 *         description: Unable to update the meeting
 */
meetingRouter.post(
  "/:meetingCode/end",
  validateParams(joinMeetingParamsSchema),
  endMeetingController,
);

export default meetingRouter;